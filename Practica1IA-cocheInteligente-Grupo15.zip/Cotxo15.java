/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agents;

/**
 *
 * @author Adrián Bennasar Polzin | Grupo nº 15
 */
public class Cotxo15 extends Agent {

    static final boolean DEBUG = false;

    static final int ESQUERRA = 0;
    static final int CENTRAL = 1;
    static final int DRETA = 2;
    static final int COTXE = 1;

    int VELOCITATTOPE = 5;
    int VELOCITATFRE = 3;

    Estat estat;
    int espera = 0;

    int retrasaAceite = 0;

    double desquerra, ddreta, dcentral;

    public Cotxo15(Agents pare) {
        super(pare, "miCoche", "imatges/miCoche.png");
    }

    @Override
    public void inicia() {
        setAngleVisors(40);
        setDistanciaVisors(350);
        setVelocitatAngular(9);
    }

    @Override
    public void avaluaComportament() {

        estat = estatCombat();  // Recuperam la informació actualitzada de l'entorn

        // PARA NO PONER ACEITE JUSTO EN LA SALIDA (QUEDARÍA MUY ALEJADO DEL CENTRO DE LA CARRETERA)
        retrasaAceite++;

        // Si volem repetir una determinada acció durant varies interaccions
        // ho hem de gestionar amb una variable (per exemple "espera") que faci
        // l'acció que volem durant el temps que necessitem
        if (espera > 0) {  // no facis res, continua amb el que estaves fent
            espera--;
            return;
        } else {

            // FUNCIONALIDAD: ARRANCAR EN PRIMERA AL INICIO DE LA CARRERA.
            if (this.estaAturat() && !(estat.enCollisio)) {
                endavant(1);
                espera = 10;
                return;
            }

            /* Importante: si el coche colisiona, para arrancar hay que controlar que empieze con la primera marcha
               y a medida que coge velocidad vaya aumentando marchas progresivamente. Esto permite un arranque mucho más
               fluido que si dejaramos puesta una marcha alta desde el inicio.
             */
            if (estat.enCollisio) {
                if (estat.distanciaVisors[CENTRAL] < 15) {
                    noGiris();
                    enrere(1);
                    espera = 30;
                    return;
                }

                noGiris();
                endavant(1);
                espera = 5;
                return;
            }

            // ACTUALIZA INFORMACIÓN DE LOS VISORES
            ddreta = estat.distanciaVisors[DRETA];
            desquerra = estat.distanciaVisors[ESQUERRA];
            dcentral = estat.distanciaVisors[CENTRAL];

            // FUNCIONALIDAD: GESTIONAR MARCHAS Y REVOLCUIONES.
            if (estat.marxa == 1 && estat.revolucions >= 3000) {
                endavant(2);
            }

            if (estat.marxa == 2 && estat.revolucions >= 3000) {
                endavant(3);
            }

            if (estat.marxa == 3 && estat.revolucions >= 3000) {
                endavant(4);
            }

            if (estat.marxa == 4 && estat.revolucions >= 3000) {
                endavant(VELOCITATTOPE);
            }

            // FUNCIONALIDAD: ESQUIVAR MANCHAS DE ACEITE
            for (int i = 0; i < estat.numObjectes; i++) {
                if (estat.objectes[i].tipus == Agent.TACAOLI) {
                    if (estat.objectes[i].sector == 2) {
                        if ((estat.objectes[i].posicio.distancia(estat.posicio) <= 70) && (estat.distanciaVisors[ESQUERRA] >= 50)) {
                            esquerra();
                            return;
                        }
                    }
                    if (estat.objectes[i].sector == 3) {
                        if ((estat.objectes[i].posicio.distancia(estat.posicio) <= 70) && (estat.distanciaVisors[DRETA] >= 50)) {
                            dreta();
                            return;
                        }
                    }
                }
            }

            /* 
                FUNCIONALIDAD: ESQUIVAR AL RIVAL. 
                    Hay un condicional para el enemigo
                    con índice 0 y para el enemigo con índice 1, ya que 
                    dependiendo de donde salgan los 2 coches en las ca-
                    rras, el índice del enemigo podrá ser 0 o 1.
             */
            if (estat.veigAlgunEnemic) {
                if (estat.veigEnemic[0]) {
                    if ((estat.sector[0] == 2) && (estat.posicioEnemic[0].distancia(estat.posicio) <= 85)) {
                        esquerra();
                        return;
                    }
                    if ((estat.sector[0] == 3) && (estat.posicioEnemic[0].distancia(estat.posicio) <= 85)) {
                        dreta();
                        return;
                    }
                }

                if (estat.veigEnemic[1]) {
                    if ((estat.sector[1] == 2) && (estat.posicioEnemic[1].distancia(estat.posicio) <= 85)) {
                        esquerra();
                        return;
                    }
                    if ((estat.sector[1] == 3) && (estat.posicioEnemic[1].distancia(estat.posicio) <= 85)) {
                        dreta();
                        return;
                    }
                }
            }

            // FUNCIONALIDAD: DISPARAR AL RIVAL.
            if (estat.objecteVisor[CENTRAL] == COTXE) {
                dispara();
            }

            // FUNCIONALIDAD: IR LO MÁS RECTO POSIBLE.
            if ((desquerra > 40) && (ddreta > 40) && dcentral > 180) {
                noGiris();
                return;
            }

            if (ddreta > desquerra) {
                dreta();
            } else {
                esquerra();
            }
            
            //FUNCIONALIDAD: UTILIZAR FRENO DE MOTOR CUANDO LA VELOCIDAD ES ELEVADA
            if (estat.marxa > VELOCITATFRE) {
                endavant(VELOCITATFRE);
            }

            // FUNCIONALIDAD: CORREGIR DIRECCIÓN CONTRARIA.
            if (this.contraDireccio()) {
                dreta();
                espera = 10;
                return;
            }

            // FUNCIONALIDAD: PONER MANCHAS DE ACEITE
            if (estat.oli > 0 && this.retrasaAceite > 150) {
                this.posaOli();
            }

            /*
            // FUNCIONALIDAD: MÉTODO ALTERNATIVO PARA ESQUIVAR MANCHAS DE ACEITE (Pensado para 25 objetos máximo en escena)
            if (estat.objectes[0].tipus == Agent.TACAOLI) {
                if (estat.objectes[0].sector == 2) {
                    if (estat.objectes[0].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[0].sector == 3) {
                    if (estat.objectes[0].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }

            if (estat.objectes[1].tipus == Agent.TACAOLI) {
                if (estat.objectes[1].sector == 2) {
                    if (estat.objectes[1].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[1].sector == 3) {
                    if (estat.objectes[1].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }

            if (estat.objectes[2].tipus == Agent.TACAOLI) {
                if (estat.objectes[2].sector == 2) {
                    if (estat.objectes[2].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[2].sector == 3) {
                    if (estat.objectes[2].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }

            if (estat.objectes[3].tipus == Agent.TACAOLI) {
                if (estat.objectes[3].sector == 2) {
                    if (estat.objectes[3].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[3].sector == 3) {
                    if (estat.objectes[3].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }

            if (estat.objectes[4].tipus == Agent.TACAOLI) {
                if (estat.objectes[4].sector == 2) {
                    if (estat.objectes[4].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[4].sector == 3) {
                    if (estat.objectes[4].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }

            if (estat.objectes[5].tipus == Agent.TACAOLI) {
                if (estat.objectes[5].sector == 2) {
                    if (estat.objectes[5].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[5].sector == 3) {
                    if (estat.objectes[5].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }

            if (estat.objectes[6].tipus == Agent.TACAOLI) {
                if (estat.objectes[6].sector == 2) {
                    if (estat.objectes[6].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[6].sector == 3) {
                    if (estat.objectes[6].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }

            if (estat.objectes[7].tipus == Agent.TACAOLI) {
                if (estat.objectes[7].sector == 2) {
                    if (estat.objectes[7].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[7].sector == 3) {
                    if (estat.objectes[7].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }

            if (estat.objectes[8].tipus == Agent.TACAOLI) {
                if (estat.objectes[8].sector == 2) {
                    if (estat.objectes[8].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[8].sector == 3) {
                    if (estat.objectes[8].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[9].tipus == Agent.TACAOLI) {
                if (estat.objectes[9].sector == 2) {
                    if (estat.objectes[9].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[9].sector == 3) {
                    if (estat.objectes[9].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[10].tipus == Agent.TACAOLI) {
                if (estat.objectes[10].sector == 2) {
                    if (estat.objectes[10].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[10].sector == 3) {
                    if (estat.objectes[10].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[11].tipus == Agent.TACAOLI) {
                if (estat.objectes[11].sector == 2) {
                    if (estat.objectes[11].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[11].sector == 3) {
                    if (estat.objectes[11].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[12].tipus == Agent.TACAOLI) {
                if (estat.objectes[12].sector == 2) {
                    if (estat.objectes[12].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[12].sector == 3) {
                    if (estat.objectes[12].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[13].tipus == Agent.TACAOLI) {
                if (estat.objectes[13].sector == 2) {
                    if (estat.objectes[13].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[13].sector == 3) {
                    if (estat.objectes[13].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[14].tipus == Agent.TACAOLI) {
                if (estat.objectes[14].sector == 2) {
                    if (estat.objectes[14].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[14].sector == 3) {
                    if (estat.objectes[14].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[15].tipus == Agent.TACAOLI) {
                if (estat.objectes[15].sector == 2) {
                    if (estat.objectes[15].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[15].sector == 3) {
                    if (estat.objectes[15].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[16].tipus == Agent.TACAOLI) {
                if (estat.objectes[16].sector == 2) {
                    if (estat.objectes[16].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[16].sector == 3) {
                    if (estat.objectes[16].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[17].tipus == Agent.TACAOLI) {
                if (estat.objectes[17].sector == 2) {
                    if (estat.objectes[17].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[17].sector == 3) {
                    if (estat.objectes[17].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[18].tipus == Agent.TACAOLI) {
                if (estat.objectes[18].sector == 2) {
                    if (estat.objectes[18].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[18].sector == 3) {
                    if (estat.objectes[18].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[19].tipus == Agent.TACAOLI) {
                if (estat.objectes[19].sector == 2) {
                    if (estat.objectes[19].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[19].sector == 3) {
                    if (estat.objectes[19].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[20].tipus == Agent.TACAOLI) {
                if (estat.objectes[20].sector == 2) {
                    if (estat.objectes[20].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[20].sector == 3) {
                    if (estat.objectes[20].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[21].tipus == Agent.TACAOLI) {
                if (estat.objectes[21].sector == 2) {
                    if (estat.objectes[21].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[21].sector == 3) {
                    if (estat.objectes[21].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[22].tipus == Agent.TACAOLI) {
                if (estat.objectes[22].sector == 2) {
                    if (estat.objectes[22].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[22].sector == 3) {
                    if (estat.objectes[22].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[23].tipus == Agent.TACAOLI) {
                if (estat.objectes[23].sector == 2) {
                    if (estat.objectes[23].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[23].sector == 3) {
                    if (estat.objectes[23].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
            
            if (estat.objectes[24].tipus == Agent.TACAOLI) {
                if (estat.objectes[24].sector == 2) {
                    if (estat.objectes[24].posicio.distancia(estat.posicio) <= 70) {
                        esquerra();
                        return;
                    }
                }
                if (estat.objectes[24].sector == 3) {
                    if (estat.objectes[24].posicio.distancia(estat.posicio) <= 70) {
                        dreta();
                        return;
                    }
                }
            }
             */
        }
    }
}
